const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, 
        AlignmentType, BorderStyle, WidthType, HeadingLevel, PageBreak } = require('docx');
const fs = require('fs');

const doc = new Document({
  sections: [{
    properties: {
      page: {
        size: {
          width: 12240,
          height: 15840
        },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
      }
    },
    children: [
      // العنوان الرئيسي
      new Paragraph({
        text: "صِحّة 2030",
        heading: HeadingLevel.TITLE,
        alignment: AlignmentType.CENTER,
        spacing: { after: 200 }
      }),
      
      new Paragraph({
        text: "المنصة الوطنية للتغذية الذكية",
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 }
      }),

      // خط فاصل
      new Paragraph({
        text: "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 }
      }),

      // الفكرة
      new Paragraph({
        text: "💡 الفكرة في سطر واحد",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "تطبيق AI يحوّل الأكل السعودي التقليدي إلى صحي ويساهم في تحقيق أهداف رؤية 2030",
            bold: true
          })
        ],
        spacing: { after: 400 }
      }),

      // المشكلة
      new Paragraph({
        text: "🔴 المشكلة",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        text: "الوضع الحالي:",
        heading: HeadingLevel.HEADING_2,
        spacing: { after: 150 }
      }),

      new Paragraph({
        text: "• 70% من السعوديين يعانون من السمنة/زيادة الوزن",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "• 25% مصابون بالسكري",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "• 35% لديهم كبد دهني",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "• 50 مليار ريال طعام مهدر سنوياً",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "• متوسط العمر: 74.9 سنة (الهدف 2030: 80 سنة)",
        spacing: { after: 300 }
      }),

      // الفجوة في السوق
      new Paragraph({
        text: "❌ الفجوة في السوق (لماذا نحن مختلفون):",
        heading: HeadingLevel.HEADING_2,
        spacing: { after: 150 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "التطبيقات الموجودة حالياً ",
            bold: true
          }),
          new TextRun({
            text: "(MyFitnessPal, Lifesum, Yazio...):"
          })
        ],
        spacing: { after: 150 }
      }),

      new Paragraph({
        text: "❌ لا تعرف الأكلات السعودية (كبسة، مندي، مطازيز، جريش، قرصان...)",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "❌ قاعدة بيانات غربية (صدر دجاج مشوي + سلطة فقط!)",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "❌ لا تفهم ثقافتنا (يقولون 'لا تأكل كبسة' بدل 'كُل كبسة صحية')",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "❌ لا تعرف المنتجات المحلية (بهارات سعودية، علامات تجارية محلية)",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "❌ لا تربط برؤية 2030 (مجرد عد سعرات)",
        spacing: { after: 300 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "✅ الفرصة الذهبية: ",
            bold: true,
            color: "008000"
          }),
          new TextRun({
            text: "أول تطبيق AI متخصص 100% في الأكل السعودي + المنتجات المحلية + المساهمة في رؤية 2030"
          })
        ],
        spacing: { after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "= سوق غير مخدوم بالكامل (Blue Ocean Market) 🌊",
            bold: true,
            color: "0066CC"
          })
        ],
        spacing: { after: 400 }
      }),

      // الحل
      new Paragraph({
        text: "✅ الحل المتكامل",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        text: "منصة واحدة - 4 ميزات مترابطة:",
        spacing: { after: 200 }
      }),

      // الميزة 1
      new Paragraph({
        text: "1️⃣ محلل الأكلات الذكي 📸",
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 200, after: 150 }
      }),

      new Paragraph({
        text: "كيف تعمل:",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "• تصور أكلتك السعودية (كبسة، مندي، مطازيز، جريش، قرصان، حنيذ...)",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• AI يحللها: سعرات، دهون، بروتين، تقييم صحي",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• يقترح نسخة صحية من نفس الأكلة (مو صدر دجاج ممل!)",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• يعطيك الوصفة كاملة",
        spacing: { after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "الفرق عن المنافسين:",
            bold: true
          })
        ],
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "❌ MyFitnessPal: 'كبسة؟ غير موجودة. سجلها يدوي.'",
        spacing: { after: 80 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "✅ صحة 2030: ",
            color: "008000",
            bold: true
          }),
          new TextRun({
            text: "'كبسة دجاج تقليدية - 850 cal، تحليل مفصل + نسخة صحية جاهزة!'"
          })
        ],
        spacing: { after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "مثال: ",
            bold: true
          }),
          new TextRun({
            text: "كبسة تقليدية: 850 cal (تقييم 4/10) → كبسة صحية: 480 cal (تقييم 9/10)"
          })
        ],
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "= نفس الطعم، أصح بـ 370 سعرة!",
        spacing: { after: 300 }
      }),

      // الميزة 2
      new Paragraph({
        text: "2️⃣ مقلل الهدر الذكي ♻️",
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 200, after: 150 }
      }),

      new Paragraph({
        text: "كيف تعمل:",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "• تصور ثلاجتك/بقايا الأكل",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• AI يقترح وجبات جديدة من المتوفر",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• ينبهك قبل ما شي يخرب",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• يحول البقايا → وجبات لذيذة",
        spacing: { after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "الفرق عن المنافسين:",
            bold: true
          })
        ],
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "❌ تطبيقات عالمية: 'بقايا أرز؟ سوي Fried Rice'",
        spacing: { after: 80 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "✅ صحة 2030: ",
            color: "008000",
            bold: true
          }),
          new TextRun({
            text: "'بقايا كبسة؟ سوي معجنات محشية سعودية، أو أرانشيني بنكهة خليجية!'"
          })
        ],
        spacing: { after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "مثال: ",
            bold: true
          }),
          new TextRun({
            text: "عندك بقايا رز + دجاج → AI يقترح: معجنات محشية = وفرت 40 ريال + ما رميت شي"
          })
        ],
        spacing: { after: 300 }
      }),

      // الميزة 3
      new Paragraph({
        text: "3️⃣ مخطط المنتج المحلي 🇸🇦",
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 200, after: 150 }
      }),

      new Paragraph({
        text: "كيف تعمل:",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "• يخطط أسبوعك من أكلات سعودية صحية",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• يقترح منتجات محلية (طماطم القصيم، دجاج الوطنية، أرز حساوي...)",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• يعرف العلامات التجارية السعودية (بهارات العروس، الشيف، المراعي...)",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• قائمة تسوق جاهزة + توصيل من المزارع",
        spacing: { after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "الفرق عن المنافسين:",
            bold: true
          })
        ],
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "❌ تطبيقات عالمية: لا تعرف المنتجات السعودية أصلاً",
        spacing: { after: 80 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "✅ صحة 2030: ",
            color: "008000",
            bold: true
          }),
          new TextRun({
            text: "'طماطم القصيم متوفرة - 5 ريال/كجم، دجاج الوطنية طازج - توصيل خلال ساعة'"
          })
        ],
        spacing: { after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "مثال: ",
            bold: true
          }),
          new TextRun({
            text: "خطة 7 أيام + قائمة تسوق، 82% منتج سعودي = أطزج + أرخص + يدعم الاقتصاد"
          })
        ],
        spacing: { after: 300 }
      }),

      // الميزة 4
      new Paragraph({
        text: "4️⃣ متتبع رؤية 2030 📊",
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 200, after: 150 }
      }),

      new Paragraph({
        text: "كيف تعمل:",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "• Dashboard يوضح مساهمتك في أهداف الرؤية",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• تتبع الصحة: كم تحسنت؟",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• تتبع البيئة: كم قللت هدر؟",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• تتبع الاقتصاد: كم دعمت المنتج المحلي؟",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• التوفير: كم وفرت فلوس؟",
        spacing: { after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "الفرق عن المنافسين:",
            bold: true
          })
        ],
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "❌ تطبيقات عالمية: 'خسرت 2 كجم - مبروك!'",
        spacing: { after: 80 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "✅ صحة 2030: ",
            color: "008000",
            bold: true
          }),
          new TextRun({
            text: "'خسرت 2 كجم + ساهمت في رؤية 2030: دعمت الاقتصاد 1,240 ريال، قللت انبعاثات 120 كجم CO2'"
          })
        ],
        spacing: { after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "مثال شهري: ",
            bold: true
          }),
          new TextRun({
            text: "تحسنت صحياً 18%، قللت هدر 45 كجم، دعمت محلي 1,240 ريال، وفرت 340 ريال، ترتيبك #234 من 50,000"
          })
        ],
        spacing: { after: 400 }
      }),

      // صفحة جديدة
      new Paragraph({
        children: [new PageBreak()]
      }),

      // الترابط
      new Paragraph({
        text: "🔗 كيف الميزات مترابطة مع بعض",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        text: "الميزات الأربعة تعمل كنظام متكامل، كل ميزة تغذي الأخرى:",
        spacing: { after: 200 }
      }),

      new Paragraph({
        text: "1. تصور أكلتك السعودية",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "   ⬇️",
        alignment: AlignmentType.LEFT,
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "2. AI يحللها + يتعلم تفضيلاتك المحلية",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "   ⬇️",
        alignment: AlignmentType.LEFT,
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "3. يقترح استغلال البقايا بطريقة سعودية (يعرف إيش عندك)",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "   ⬇️",
        alignment: AlignmentType.LEFT,
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "4. يخطط أسبوعك من منتج محلي (بناءً على تفضيلاتك)",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "   ⬇️",
        alignment: AlignmentType.LEFT,
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "5. يتتبع كل شي ويحفزك (مساهمة وطنية!)",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "   ⬇️",
        alignment: AlignmentType.LEFT,
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "6. دورة مستمرة = تحسن مستمر 🔄",
        spacing: { after: 300 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "النتيجة: ",
            bold: true
          }),
          new TextRun({
            text: "نظام ذكي متكامل يتعلم منك ويتحسن، يحل مشاكل متعددة بحل واحد = أثر مضاعف"
          })
        ],
        spacing: { after: 400 }
      }),

      // الربط برؤية 2030
      new Paragraph({
        text: "🇸🇦 الربط برؤية 2030",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        text: "كل ميزة تخدم هدف محدد من أهداف رؤية 2030:",
        spacing: { after: 200 }
      }),

      // جدول الربط
      new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [
          new TableRow({
            children: [
              new TableCell({
                children: [new Paragraph({ text: "هدف الرؤية", bold: true })],
                width: { size: 30, type: WidthType.PERCENTAGE }
              }),
              new TableCell({
                children: [new Paragraph({ text: "الميزة المرتبطة", bold: true })],
                width: { size: 35, type: WidthType.PERCENTAGE }
              }),
              new TableCell({
                children: [new Paragraph({ text: "كيف نساهم", bold: true })],
                width: { size: 35, type: WidthType.PERCENTAGE }
              })
            ]
          }),
          new TableRow({
            children: [
              new TableCell({
                children: [new Paragraph("Quality of Life\n(جودة الحياة) 💪")]
              }),
              new TableCell({
                children: [new Paragraph("محلل الأكلات +\nنسخ صحية")]
              }),
              new TableCell({
                children: [new Paragraph("تحسين الصحة العامة\n+ رفع متوسط العمر\nمن 74 → 80 سنة")]
              })
            ]
          }),
          new TableRow({
            children: [
              new TableCell({
                children: [new Paragraph("Sustainability\n(الاستدامة) ♻️")]
              }),
              new TableCell({
                children: [new Paragraph("مقلل الهدر +\nاستغلال البقايا")]
              }),
              new TableCell({
                children: [new Paragraph("تقليل 50 مليار ريال هدر\n+ Saudi Green Initiative\n+ الاقتصاد الدائري")]
              })
            ]
          }),
          new TableRow({
            children: [
              new TableCell({
                children: [new Paragraph("Food Security\n(الأمن الغذائي) 🌾")]
              }),
              new TableCell({
                children: [new Paragraph("مخطط المنتج المحلي +\nربط المزارع")]
              }),
              new TableCell({
                children: [new Paragraph("دعم المنتج السعودي\n+ الاكتفاء الذاتي\n+ تنويع الاقتصاد")]
              })
            ]
          }),
          new TableRow({
            children: [
              new TableCell({
                children: [new Paragraph("Digital Transformation\n(التحول الرقمي) 📱")]
              }),
              new TableCell({
                children: [new Paragraph("AI + Machine Learning\nعبر كل الميزات")]
              }),
              new TableCell({
                children: [new Paragraph("Innovation في Health Tech\n+ حلول ذكية\n+ قيادة تقنية")]
              })
            ]
          })
        ]
      }),

      new Paragraph({
        text: "",
        spacing: { after: 300 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "الخلاصة: ",
            bold: true
          }),
          new TextRun({
            text: "كل ميزة تخدم هدف، ومجتمعة = أثر أكبر وشامل على رؤية 2030"
          })
        ],
        spacing: { after: 400 }
      }),

      // صفحة جديدة
      new Paragraph({
        children: [new PageBreak()]
      }),

      // المقارنة مع المنافسين
      new Paragraph({
        text: "🆚 المقارنة مع المنافسين",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      // جدول المقارنة
      new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [
          new TableRow({
            children: [
              new TableCell({
                children: [new Paragraph({ text: "الميزة", bold: true })],
                width: { size: 33, type: WidthType.PERCENTAGE }
              }),
              new TableCell({
                children: [new Paragraph({ text: "التطبيقات العالمية", bold: true })],
                width: { size: 33, type: WidthType.PERCENTAGE }
              }),
              new TableCell({
                children: [new Paragraph({ text: "صحة 2030", bold: true })],
                width: { size: 34, type: WidthType.PERCENTAGE }
              })
            ]
          }),
          new TableRow({
            children: [
              new TableCell({ children: [new Paragraph("الأكلات السعودية")] }),
              new TableCell({ children: [new Paragraph("❌ غير موجودة")] }),
              new TableCell({ children: [new Paragraph("✅ 100+ أكلة شعبية")] })
            ]
          }),
          new TableRow({
            children: [
              new TableCell({ children: [new Paragraph("المنتجات المحلية")] }),
              new TableCell({ children: [new Paragraph("❌ لا يعرفونها")] }),
              new TableCell({ children: [new Paragraph("✅ قاعدة بيانات كاملة")] })
            ]
          }),
          new TableRow({
            children: [
              new TableCell({ children: [new Paragraph("فهم الثقافة")] }),
              new TableCell({ children: [new Paragraph("❌ 'لا تأكل كبسة'")] }),
              new TableCell({ children: [new Paragraph("✅ 'كُل كبسة صحية'")] })
            ]
          }),
          new TableRow({
            children: [
              new TableCell({ children: [new Paragraph("ربط رؤية 2030")] }),
              new TableCell({ children: [new Paragraph("❌ غير موجود")] }),
              new TableCell({ children: [new Paragraph("✅ محور أساسي")] })
            ]
          }),
          new TableRow({
            children: [
              new TableCell({ children: [new Paragraph("دعم المنتج المحلي")] }),
              new TableCell({ children: [new Paragraph("❌ غير موجود")] }),
              new TableCell({ children: [new Paragraph("✅ ربط مع المزارع")] })
            ]
          }),
          new TableRow({
            children: [
              new TableCell({ children: [new Paragraph("تقليل الهدر")] }),
              new TableCell({ children: [new Paragraph("❌ محدود")] }),
              new TableCell({ children: [new Paragraph("✅ ذكي ومتكامل")] })
            ]
          }),
          new TableRow({
            children: [
              new TableCell({ children: [new Paragraph("اللغة العربية")] }),
              new TableCell({ children: [new Paragraph("❌ ضعيف")] }),
              new TableCell({ children: [new Paragraph("✅ عربي أصيل (RTL)")] })
            ]
          })
        ]
      }),

      new Paragraph({
        text: "",
        spacing: { after: 300 }
      }),

      // الميزة التنافسية
      new Paragraph({
        text: "💡 الميزة التنافسية (Competitive Advantage)",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        text: "✅ Local Expertise (خبرة محلية):",
        heading: HeadingLevel.HEADING_2,
        spacing: { after: 150 }
      }),

      new Paragraph({
        text: "• فهم عميق للأكل السعودي وطرق التحضير التقليدية",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• قاعدة بيانات شاملة للمنتجات والعلامات التجارية المحلية",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• شراكات مع مزارع ومحلات سعودية",
        spacing: { after: 200 }
      }),

      new Paragraph({
        text: "✅ Cultural Fit (توافق ثقافي):",
        heading: HeadingLevel.HEADING_2,
        spacing: { after: 150 }
      }),

      new Paragraph({
        text: "• لا نفرض أكل غربي على المستخدمين",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• نحترم ونحسّن الأكل السعودي التقليدي",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• نفهم العادات الغذائية والمناسبات الاجتماعية",
        spacing: { after: 200 }
      }),

      new Paragraph({
        text: "✅ National Mission (رسالة وطنية):",
        heading: HeadingLevel.HEADING_2,
        spacing: { after: 150 }
      }),

      new Paragraph({
        text: "• مرتبطون مباشرة برؤية 2030",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• إمكانية الحصول على دعم حكومي",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• شراكات محتملة مع الوزارات (الصحة، البيئة، الزراعة)",
        spacing: { after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "= First Mover Advantage في سوق غير مستغل! 🚀",
            bold: true,
            color: "0066CC"
          })
        ],
        spacing: { after: 400 }
      }),

      // حجم السوق
      new Paragraph({
        text: "📊 حجم السوق والفرصة",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        text: "• 20 مليون سعودي (70% يعانون من السمنة)",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• 10 مليون عائلة سعودية",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• السوق المحتمل: 3.5 مليار ريال سنوياً",
        spacing: { after: 80 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "• سوق غير مخدوم = فرصة ذهبية! 🏆",
            bold: true,
            color: "FFD700"
          })
        ],
        spacing: { after: 400 }
      }),

      // نموذج الربح
      new Paragraph({
        text: "💰 نموذج الربح",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        text: "🆓 مجاني: 5 تحليلات شهرياً",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "💎 Premium: 29 ريال/شهر (تحليل غير محدود + كل الميزات)",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "🏢 للشركات/المدارس: باقات مخصصة حسب الحجم",
        spacing: { after: 100 }
      }),

      new Paragraph({
        text: "🏛️ شراكات حكومية: برامج وطنية وحملات توعية",
        spacing: { after: 400 }
      }),

      // صفحة جديدة
      new Paragraph({
        children: [new PageBreak()]
      }),

      // خطة الهاكاثون
      new Paragraph({
        text: "⚡ خطة الهاكاثون (يومين)",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "التركيز: ",
            bold: true
          }),
          new TextRun({
            text: "نبني الميزة الأساسية فقط (محلل الأكلات) ونعرض الرؤية الكاملة في الـ Pitch"
          })
        ],
        spacing: { after: 300 }
      }),

      new Paragraph({
        text: "📅 اليوم الأول:",
        heading: HeadingLevel.HEADING_2,
        spacing: { after: 150 }
      }),

      new Paragraph({
        text: "✅ صفحة upload صورة الأكلة",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "✅ ربط Claude API للتحليل",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "✅ قاعدة بيانات بسيطة (10-15 أكلة سعودية شائعة)",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "✅ تجربة أولية للتحليل",
        spacing: { after: 300 }
      }),

      new Paragraph({
        text: "📅 اليوم الثاني:",
        heading: HeadingLevel.HEADING_2,
        spacing: { after: 150 }
      }),

      new Paragraph({
        text: "✅ صفحة النتائج + اقتراح النسخة الصحية",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "✅ Dashboard بسيط لمتتبع رؤية 2030",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "✅ تحسين UI/UX وجعله responsive",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "✅ Deploy على Vercel",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "✅ تحضير الـ Pitch والعرض التقديمي",
        spacing: { after: 400 }
      }),

      // التقنيات
      new Paragraph({
        text: "🛠️ التقنيات المستخدمة",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        text: "• Frontend: Next.js + Tailwind CSS",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• AI: Claude API (Anthropic)",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• Hosting: Vercel (مجاني وسريع)",
        spacing: { after: 80 }
      }),

      new Paragraph({
        text: "• Database: JSON files (بسيطة ليومين، يمكن الترقية لاحقاً)",
        spacing: { after: 400 }
      }),

      // الخلاصة النهائية
      new Paragraph({
        text: "✅ الخلاصة النهائية",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "صحة 2030 = ",
            bold: true,
            size: 28
          }),
          new TextRun({
            text: "أول تطبيق سعودي متخصص + AI + رؤية 2030",
            size: 28
          })
        ],
        spacing: { after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "= Blue Ocean Market ",
            bold: true,
            color: "0066CC"
          }),
          new TextRun({
            text: "(سوق غير مستغل بالكامل)"
          })
        ],
        spacing: { after: 100 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "= First Mover Advantage ",
            bold: true,
            color: "008000"
          }),
          new TextRun({
            text: "(أول من يدخل السوق)"
          })
        ],
        spacing: { after: 100 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: "= National Impact ",
            bold: true,
            color: "FF6600"
          }),
          new TextRun({
            text: "(أثر وطني على الصحة والبيئة والاقتصاد)"
          })
        ],
        spacing: { after: 400 }
      }),

      // الـ Pitch
      new Paragraph({
        text: "🎬 الـ Pitch (30 ثانية)",
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 200 }
      }),

      new Paragraph({
        children: [
          new TextRun({
            text: '"70% من السعوديين سمنة. ليش؟"\n\n',
            italics: true
          }),
          new TextRun({
            text: '"لأن التطبيقات العالمية ما تعرف كبستنا، منديننا، قرصاننا."\n\n',
            italics: true
          }),
          new TextRun({
            text: '"يقولون: لا تأكل كبسة. نحن نقول: كُل كبسة صحية!"\n\n',
            italics: true,
            bold: true
          }),
          new TextRun({
            text: '"صحة 2030 - أول تطبيق AI متخصص 100% في الأكل السعودي."\n\n',
            italics: true
          }),
          new TextRun({
            text: '"صوّر أكلتك → نحولها صحية → تساهم في رؤية 2030."\n\n',
            italics: true
          }),
          new TextRun({
            text: '"سوق بـ 3.5 مليار ريال. غير مخدوم. فرصتنا الآن."',
            italics: true,
            bold: true
          })
        ],
        spacing: { after: 400 }
      }),

      // الختام
      new Paragraph({
        text: "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        alignment: AlignmentType.CENTER,
        spacing: { before: 400, after: 200 }
      }),

      new Paragraph({
        text: "جاهزون للانطلاق! 🚀",
        alignment: AlignmentType.CENTER,
        spacing: { after: 200 },
        heading: HeadingLevel.HEADING_1
      }),

      new Paragraph({
        text: "🇸🇦",
        alignment: AlignmentType.CENTER,
        spacing: { after: 0 }
      })
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/home/claude/صحة_2030_ملخص_المشروع.docx", buffer);
  console.log("✅ تم إنشاء الملف بنجاح!");
  console.log("📄 اسم الملف: صحة_2030_ملخص_المشروع.docx");
});
